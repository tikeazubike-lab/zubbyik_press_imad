/**
 * Global Animations
 *
 * - Section title eyebrow reveal.
 * - Smooth anchor scrolling.
 * - Theme toggle persistence.
 *
 * @package Malachy_Portfolio
 */

document.addEventListener('DOMContentLoaded', function () {

  // ---- Theme Toggle ----
  const toggle = document.getElementById('theme-toggle');
  const sun = document.getElementById('theme-sun');
  const moon = document.getElementById('theme-moon');

  function setTheme(dark) {
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('theme', dark ? 'dark' : 'light');
    if (sun && moon) {
      sun.style.display = dark ? 'none' : 'block';
      moon.style.display = dark ? 'block' : 'none';
    }
  }

  // Initial state
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  setTheme(saved === 'dark' || (!saved && prefersDark));

  toggle?.addEventListener('click', () => {
    setTheme(!document.documentElement.classList.contains('dark'));
  });

  // ---- Smooth anchor scrolling ----
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const offset = 100;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  // ---- Blog cards reveal ----
  const blogGrid = document.getElementById('blog-grid');
  if (blogGrid) {
    const blogCards = blogGrid.querySelectorAll('.blog-card');
    gsap.from(blogCards, {
      scrollTrigger: {
        trigger: blogGrid,
        start: 'top 85%',
        end: 'top 40%',
        scrub: 1,
      },
      y: 40,
      opacity: 0,
      stagger: 0.15,
      ease: 'power2.out',
    });
  }
});
