/**
 * Projects Section Animation
 *
 * - Stacked sticky cards (desktop/tablet).
 * - Current project scales down slightly; next project slides over.
 * - Images lazy load.
 *
 * Mobile Pinning Exception: stack pin is gated behind matchMedia at >= 768px.
 * Below that, projects are simple fade/translate scroll reveals.
 *
 * @package Malachy_Portfolio
 */

document.addEventListener('DOMContentLoaded', function () {
  const section = document.getElementById('projects');
  const stack = document.getElementById('projects-stack');
  if (!section || !stack) return;

  const cards = stack.querySelectorAll('.proj-card');
  if (cards.length === 0) return;

  const mm = gsap.matchMedia();

  // Desktop/Tablet: sticky stack with scale/translate scrub
  mm.add('(min-width: 768px)', () => {
    // First card acts as the pin anchor
    ScrollTrigger.create({
      trigger: stack,
      start: 'top 5rem',
      end: () => '+=' + (cards.length * window.innerHeight * 0.8),
      pin: true,
      pinSpacing: true,
      anticipatePin: 1,
    });

    // Each card animates through the stack
    cards.forEach((card, i) => {
      // Card content fades/in on entry
      const image = card.querySelector('.proj-card-image');
      const body = card.querySelector('.proj-card-body');

      if (image) {
        gsap.from(image, {
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 40%',
            scrub: 1,
          },
          x: -80,
          opacity: 0,
          ease: 'power2.out',
        });
      }

      if (body) {
        gsap.from(body, {
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 40%',
            scrub: 1,
          },
          x: 80,
          opacity: 0,
          ease: 'power2.out',
        });
      }
    });
  });

  // Mobile: simple fade reveal
  mm.add('(max-width: 767px)', () => {
    cards.forEach(card => {
      gsap.from(card, {
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          end: 'top 50%',
          scrub: 1,
        },
        y: 40,
        opacity: 0,
        ease: 'power2.out',
      });
    });
  });
});
