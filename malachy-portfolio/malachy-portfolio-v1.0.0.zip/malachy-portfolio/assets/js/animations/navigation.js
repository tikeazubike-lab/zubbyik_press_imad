/**
 * Navigation Animation
 *
 * - Sticky glassmorphism header.
 * - Shrinks on scroll.
 * - Mobile menu animation.
 * - Active link highlighting.
 *
 * @package Malachy_Portfolio
 */

document.addEventListener('DOMContentLoaded', function () {
  const header = document.getElementById('site-header');
  const logo = header?.querySelector('.nav-logo');
  const toggle = document.getElementById('mobile-menu-toggle');
  const menu = document.getElementById('mobile-menu');
  const links = menu?.querySelectorAll('a[data-section-link]');

  if (!header) return;

  // Scroll-based glassmorphism
  gsap.to(header, {
    scrollTrigger: {
      trigger: document.body,
      start: 'top -80px',
      end: 'top -120px',
      onEnter: () => header.classList.add('nav-scrolled'),
      onLeaveBack: () => header.classList.remove('nav-scrolled'),
    },
  });

  // Mobile menu toggle
  toggle?.addEventListener('click', function () {
    const isOpen = menu.style.display !== 'none';
    menu.style.display = isOpen ? 'none' : 'block';
    document.getElementById('menu-icon-open').style.display = isOpen ? 'block' : 'none';
    document.getElementById('menu-icon-close').style.display = isOpen ? 'none' : 'block';
  });

  // Close mobile menu on link click
  links?.forEach(link => {
    link.addEventListener('click', function () {
      menu.style.display = 'none';
      document.getElementById('menu-icon-open').style.display = 'block';
      document.getElementById('menu-icon-close').style.display = 'none';
    });
  });

  // Desktop link active state based on scroll position
  const sections = ['home', 'about', 'skills', 'projects', 'experience', 'blog', 'contact'];
  const navLinks = header.querySelectorAll('.nav-desktop-link');

  sections.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    ScrollTrigger.create({
      trigger: el,
      start: 'top center',
      end: 'bottom center',
      onEnter: () => setActive(id),
      onEnterBack: () => setActive(id),
    });
  });

  function setActive(id) {
    navLinks.forEach(link => {
      const href = link.getAttribute('href').replace('/', '');
      link.classList.toggle('active', href === `#${id}`);
    });
  }
});
