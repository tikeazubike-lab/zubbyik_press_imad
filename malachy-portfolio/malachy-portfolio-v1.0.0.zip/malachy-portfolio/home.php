<?php
/**
 * Blog Archive Template (home.php)
 *
 * Source: React routes/blog.tsx — full blog listing page.
 *
 * @package Malachy_Portfolio
 */

get_header();
?>
<section class="blog-page">
	<div class="container-x">
		<div class="blog-page-header">
			<p class="section-eyebrow">
				<span class="hero-eyebrow-line"></span>
				<?php esc_html_e( 'Writing', 'malachy-portfolio' ); ?>
			</p>
			<h1 class="blog-page-title">
				<?php esc_html_e( 'Notes from the shop.', 'malachy-portfolio' ); ?>
			</h1>
		</div>

		<div class="blog-post-list">
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<article class="blog-post-item">
						<div class="blog-post-meta">
							<span><?php
							$cats = get_the_category();
							echo esc_html( ! empty( $cats ) ? $cats[0]->name : __( 'Article', 'malachy-portfolio' ) );
							?></span>
							<span class="blog-post-meta-date"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></span>
						</div>
						<h2 class="blog-post-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
						<p class="blog-post-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
					</article>
				<?php endwhile; ?>

				<?php the_posts_pagination(); ?>

			<?php else : ?>
				<p><?php esc_html_e( 'No posts yet. Check back soon.', 'malachy-portfolio' ); ?></p>
			<?php endif; ?>
		</div>

		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="blog-back-link">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
			<?php esc_html_e( 'Back to home', 'malachy-portfolio' ); ?>
		</a>
	</div>
</section>
<?php
get_footer();
